package bank;

import java.util.HashMap;

import user.User;

public class Bank implements IBank {
    /**
     * Istanza singleton della banca.
     */
    private static Bank instance; 
    /**t
     * Conto di tutti gli utenti.
     */
    HashMap<String, Integer> accounts = new HashMap<>();

    private Bank(){ }

    public static Bank getInstance() {
        if(null == instance)
            instance = new Bank();
        return instance;
    }

    @Override
    public void addAccount(User user, int amount) {
        accounts.put(user.getName(), amount);
    }

    @Override
    public int getAmount(User user) {
        return accounts.get(user.getName());
    }

    @Override
    public boolean buyTicket(User user, int price) {
        int bilancio = accounts.get(user.getName());
        
        if (bilancio - price >= 0){
            accounts.put(user.getName(), bilancio-price);
            System.out.println("IL TICKET E' STATO APPROVATO DALLA BANCA PER " + user.getName());
            return true;
        }
        System.out.println("IL TICKET NON E' STATO APPROVATO DALLA BANCA PER " + user.getName());
        return false;
    }
}
