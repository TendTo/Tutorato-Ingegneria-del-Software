package metro;

public interface TicketState{
    public TicketState use();
    public TicketState validate();
    public boolean isExpired();
    public boolean isValidated();
}