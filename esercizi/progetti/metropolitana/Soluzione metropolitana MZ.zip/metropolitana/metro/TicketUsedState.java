package metro;

public class TicketUsedState implements TicketState{
    public TicketState use(){
        System.out.println("Biglietto già usato. Impossibile usare di nuovo.");
        return this;
    }

    public TicketState validate(){
        System.out.println("Non è possibile validare un ticket usato.");
        return this;

    }

    public boolean isExpired(){
        return true;
    }

    public boolean isValidated(){
        return true;
    }
}