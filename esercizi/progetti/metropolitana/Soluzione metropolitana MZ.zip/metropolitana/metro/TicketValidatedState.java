package metro;

public class TicketValidatedState implements TicketState{
    public TicketState use(){
        return new TicketUsedState();
    }

    public TicketState validate(){
        System.out.println("Ticket gia' valido");
        return this;
    }

    public boolean isExpired(){
        return false;
    }

    public boolean isValidated(){
        return true;
    }
}