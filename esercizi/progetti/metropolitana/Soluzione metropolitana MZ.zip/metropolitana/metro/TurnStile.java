package metro;

import user.User;

public class TurnStile implements ITurnstile{
    private boolean aperto = false;

    public void insertTicket(ITicket ticket){
        if(!ticket.isExpired() && ticket.isValidated()) {
            ticket.use();
            aperto = true;
            System.out.println("Ticket approvato. Il tornello si apre");
        }
    }



	@Override
	public void goThrough(User user) {
		if(aperto) 
            System.out.println(user.getName() + " e' entrato nel tornello");
        else 
            System.out.println(user.getName() + " non e' entrato nel tornello");

        aperto = false;

	}



}