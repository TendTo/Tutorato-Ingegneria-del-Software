package metro;

public class TicketNormalState implements TicketState{
    public TicketState use(){
        return new TicketUsedState();
    }

    public TicketState validate(){
        return new TicketValidatedState();

    }

    public boolean isExpired(){
        return false;
    }

    public boolean isValidated(){
        return false;
    }
}