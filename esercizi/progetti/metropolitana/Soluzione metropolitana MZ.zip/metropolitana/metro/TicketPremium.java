package metro;

public class TicketPremium extends Ticket{
    private static final int COSTO = 2;
    public int getCost(){
        return COSTO;
    }
}