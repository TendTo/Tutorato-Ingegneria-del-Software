package metro;

public class TicketStandard extends Ticket{
    private static final int COSTO = 1;

    public int getCost(){
        return COSTO;
    }
}