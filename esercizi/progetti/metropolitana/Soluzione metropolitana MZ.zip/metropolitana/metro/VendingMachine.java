package metro;

import bank.Bank;
import metro.ITicket.TicketType;
import user.User;

public class VendingMachine implements IVendingMachine {

	@Override
	public ITicket buyTicket(User user, TicketType type) {
        ITicket ticket = switch (type) {
            case STANDARD -> new TicketStandard();
            case PREMIUM -> new TicketPremium();
            default -> null;
        };
        if (ticket == null || !Bank.getInstance().buyTicket(user, ticket.getCost()))
            return null;
        System.out.println("IL TICKET PREMIUM DELLA MACCHINA E' STATO ACQUISTATO DA " + user.getName());
        return ticket;
	}
}