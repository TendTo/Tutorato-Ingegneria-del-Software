package metro;

public abstract class Ticket implements ITicket{
    private TicketState state;

    public Ticket(){
        this.state = new TicketNormalState();
    }

    public void use(){
        state = state.use();
    }

    public void validate(){
        state = state.validate();
    }

    public boolean isExpired(){
        return state.isExpired();
    }

    public boolean isValidated(){
        return state.isValidated();
    }
}