package test;

import bank.Bank;

import user.User;

public class TestBank {

    public static void main(String[] args) {
        Bank bank = Bank.getInstance();
        User user1 = new User("Vito");
        User user2 = new User("Lele");

        // Test addAccount()
        System.out.println("Initial balance of user1: " + bank.getAmount(user1)); // null
        System.out.println("Adding 100 to user1's account");
        bank.addAccount(user1, 100.0);
        System.out.println("Balance of user1 after adding 100: " + bank.getAmount(user1)); // 100.0
        System.out.println("Adding 50 to user1's account again");
        bank.addAccount(user1, 50.0);
        System.out.println("Balance of user1 after adding 50 again: " + bank.getAmount(user1)); // 100.0 (account
                                                                                                // already exists)

        // Test buyTicket()
        System.out.println("Buying ticket for user1 with price 75");
        bank.buyTicket(user1, 75.0); // Ticket purchase successful for user Vito
        System.out.println("Balance of user1 after buying ticket: " + bank.getAmount(user1)); // 25.0
        System.out.println("Trying to buy ticket for user1 with price 100");
        bank.buyTicket(user1, 100.0); // Ticket purchase failed for user Vito
        System.out.println(
                "Balance of user1 after trying to buy ticket with insufficient funds: " + bank.getAmount(user1)); // 25.0

        System.out.println("Buying ticket for user2 with price 50");
        bank.buyTicket(user2, 50.0); // Ticket purchase failed for user Lele
        System.out.println("Balance of user2 after trying to buy ticket with no account: " + bank.getAmount(user2)); // null
    }

}
