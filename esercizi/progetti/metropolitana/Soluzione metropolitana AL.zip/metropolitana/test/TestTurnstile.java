package test;

import metro.*;
import user.*;

public class TestTurnstile {
    public static void main(String[] args) {
        User u = new User("Ture");
        ITurnstile turnstile = new Turnstile();
        // CANNOT ENTER
        turnstile.goThrough(u);
        // SHOULD ENTER
        turnstile.insertTicket(u.getTicket());
        turnstile.goThrough(u);
    }
}