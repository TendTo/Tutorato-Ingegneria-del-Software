package metro;

import user.User;

public interface TurnstileState {
    public TurnstileState goThrough(User user);

    public TurnstileState insertTicket(ITicket ticket);
}