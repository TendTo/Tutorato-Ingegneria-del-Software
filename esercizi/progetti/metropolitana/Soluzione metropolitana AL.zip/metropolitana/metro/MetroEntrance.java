package metro;

/**
 * Singleton che effettua un load balancing sui {@link metro.ITurnstile
 * tornelli} e sulle {@link metro.IVendingMachine biglietterie} della
 * metro.
 */
public class MetroEntrance {
    /**
     * Istanza del singleton.
     */
    private static MetroEntrance instance; // = new MetroEntrance();
    /**
     * Lista dei tornelli della metro.
     */
    private ITurnstile[] turnstiles; // = new ITurnstile[4];
    private int turnTurnstile;
    /**
     * Lista dei tornelli della metro.
     */
    private IVendingMachine[] vendingMachines; // = new IVendingMachine[2];
    private int turnVendingMachine;

    /**
     * Costruttore privato del singleton.
     */
    private MetroEntrance() {
        turnstiles = new Turnstile[4];
        vendingMachines = new VendingMachine[2];
        for (int i = 0; i < 4; i++) {
            turnstiles[i] = new Turnstile();
        }
        for (int i = 0; i < 2; i++) {
            vendingMachines[i] = new VendingMachine();
        }
        turnTurnstile = 0;
        turnVendingMachine = 0;
    }

    /**
     * Ritorna l'istanza del singleton.
     * 
     * @return istanza del singleton
     */
    public static MetroEntrance getInstance() {
        if (instance == null) {
            instance = new MetroEntrance();
        }
        return instance;
    }

    /**
     * Ritorna un {@link metro.ITurnstile tornello}, con un load balancing
     * round-robin.
     * 
     * @return {@link metro.ITurnstile tornello}
     */
    public ITurnstile getTurnstile() {
        if (turnTurnstile > turnstiles.length - 1) {
            turnTurnstile = 0;
        }

        return turnstiles[turnTurnstile++];
    }

    /**
     * Ritorna una {@link metro.IVendingMachine biglietteria}, con un load
     * balancing round-robin.
     * 
     * @return {@link metro.IVendingMachine biglietteria}
     */
    public IVendingMachine getVendingMachine() {
        if (turnVendingMachine > vendingMachines.length - 1) {
            turnVendingMachine = 0;
        }
        return vendingMachines[turnVendingMachine++];
    }
}
