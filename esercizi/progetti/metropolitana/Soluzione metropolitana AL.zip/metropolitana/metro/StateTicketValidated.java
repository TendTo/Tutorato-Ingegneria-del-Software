package metro;

public class StateTicketValidated implements StateTicket {
    @Override
    public StateTicket validate() {
        System.out.println("This ticket was already validated.");
        return this;
    }

    @Override
    public StateTicket use() {
        System.out.println("You used the ticket.");
        return new StateTicketExpired();
    }

    @Override
    public boolean isValidated() {
        return true;
    }

    @Override
    public boolean isExpired() {
        return false;
    }
}