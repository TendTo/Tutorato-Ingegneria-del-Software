package metro;

public class StateTicketExpired implements StateTicket {
    @Override
    public StateTicket validate() {
        System.out.println("This ticket was already validated.");
        return this;
    }

    @Override
    public StateTicket use() {
        System.out.println("This ticket was already used.");
        return this;
    }

    @Override
    public boolean isValidated() {
        return true;
    }

    @Override
    public boolean isExpired() {
        return true;
    }
}