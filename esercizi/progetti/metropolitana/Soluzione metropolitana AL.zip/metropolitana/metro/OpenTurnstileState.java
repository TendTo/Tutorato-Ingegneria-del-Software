package metro;

import user.User;

public class OpenTurnstileState implements TurnstileState {

    @Override
    public TurnstileState goThrough(User user) {
        System.out.println("Sei entrato");
        return new CloseTurnstileState();
    }

    @Override
    public TurnstileState insertTicket(ITicket ticket) {
        return this;
    }
}