package metro;

import user.User;
import bank.Bank;

class VendingMachine implements IVendingMachine {
    VendingMachine() {
    }

    final private double STANDARD_COST = 1.0;
    final private double PREMIUM_COST = 2.0;

    public ITicket buyTicket(User user, ITicket.TicketType type) {

        Bank b = Bank.getInstance();
        boolean sold = false;
        switch (type) {
            case STANDARD:
                sold = b.buyTicket(user, STANDARD_COST);
                if (sold == true) {
                    return new PremiumTicket();
                }
                break;

            case PREMIUM:
                sold = b.buyTicket(user, PREMIUM_COST);
                if (sold == true) {
                    return new StandardTicket();
                }
                break;
        }

        return null;
    }
}