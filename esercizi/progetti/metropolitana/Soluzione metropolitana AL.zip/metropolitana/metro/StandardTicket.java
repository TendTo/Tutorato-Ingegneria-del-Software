package metro;

public class StandardTicket implements ITicket {
    StateTicket stateTicket;

    public StandardTicket() {
        stateTicket = new StateTicketNew();
    }

    @Override
    public void validate() {
        stateTicket = stateTicket.validate();
    }

    @Override
    public void use() {
        stateTicket = stateTicket.use();
    }

    @Override
    public boolean isExpired() {

        return stateTicket.isExpired();
    }

    @Override
    public boolean isValidated() {

        return stateTicket.isValidated();
    }

    @Override
    public int getCost() {
        return 1;
    }

}