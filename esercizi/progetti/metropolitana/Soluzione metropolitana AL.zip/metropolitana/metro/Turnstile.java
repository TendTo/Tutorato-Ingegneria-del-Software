package metro;

import user.User;

public class Turnstile implements ITurnstile {

    private TurnstileState state = new CloseTurnstileState();

    public Turnstile() {
        this.state = new CloseTurnstileState();
    }

    @Override
    public void insertTicket(ITicket ticket) {
        state = state.insertTicket(ticket);
    }

    @Override
    public void goThrough(User user) {
        state = state.goThrough(user);
    }
}