package metro;

import user.User;

public class CloseTurnstileState implements TurnstileState {

    @Override
    public TurnstileState goThrough(User user) {
        System.out.println("Entrata negata.");
        return this;
    }

    @Override
    public TurnstileState insertTicket(ITicket ticket) {
        if(ticket.isExpired()) {
            System.out.println("Il ticket è scaduto.");
            return this;
        } else if(ticket.isValidated()) {
            ticket.use();
            return new OpenTurnstileState();
        } else {
            System.out.println("Devi prima validare il ticket e poi riprovi.");
            return this;
        }
    }
}