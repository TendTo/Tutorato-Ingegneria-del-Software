package metro;

public class StateTicketNew implements StateTicket {
    @Override
    public StateTicket validate() {
        System.out.println("Your ticket has been validated.");
        return new StateTicketValidated();
    }

    @Override
    public StateTicket use() {
        System.out.println("You need to validate this ticket before using it.");
        return this;
    }

    @Override
    public boolean isValidated() {
        return false;
    }

    @Override
    public boolean isExpired() {
        return false;
    }

}