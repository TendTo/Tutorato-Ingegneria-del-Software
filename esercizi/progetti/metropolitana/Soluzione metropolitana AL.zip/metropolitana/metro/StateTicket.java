package metro;

public interface StateTicket {

    public StateTicket validate();

    public StateTicket use();

    public boolean isExpired();

    public boolean isValidated();

}