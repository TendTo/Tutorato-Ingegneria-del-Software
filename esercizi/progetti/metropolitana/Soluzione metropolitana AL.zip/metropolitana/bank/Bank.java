package bank;

import java.util.HashMap;

import user.User;

public class Bank implements IBank {
    /**
     * Istanza singleton della banca.
     */
    private static Bank instance = null;
    /**
     * Conto di tutti gli utenti.
     */
    HashMap<User, Double> accounts = new HashMap<>();

    private Bank() {
    }

    public static Bank getInstance() {
        if (null == instance) {
            instance = new Bank();
        }
        return instance;
    }

    private boolean alreadyExists(User user) {
        return accounts.containsKey(user);
    }

    @Override
    public void addAccount(User user, Double amount) {
        if (!alreadyExists(user))
            accounts.put(user, amount);
    }

    @Override
    public Double getAmount(User user) {
        return accounts.get(user);
    }

    @Override
    public boolean buyTicket(User user, Double price) {
        Double currentAmount = accounts.get(user);
        if (currentAmount != null && currentAmount >= price) {
            accounts.put(user, currentAmount - price);
            System.out.println("Ticket purchase successful for user " + user);
            return true;
        }
        System.out.println("Ticket purchase failed for user " + user);
        return false;
    }
}
